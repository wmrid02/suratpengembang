<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . (strpos($_SERVER['SCRIPT_NAME'], '/surat/') !== false ? '../login.php' : 'login.php'));
    exit;
}
