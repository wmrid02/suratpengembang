<?php
$current = basename($_SERVER['SCRIPT_NAME']);
$base_url = $base_url ?? '';
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <i class="bi bi-envelope-paper-fill"></i>
        <span>SURAT PENGEMBANG TIK</span>
    </div>

    <ul class="sidebar-menu">
        <li class="<?= $current === 'index.php' ? 'active' : '' ?>">
            <a href="<?= $base_url ?>index.php">
                <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
            </a>
        </li>

        <li class="has-submenu <?= in_array($current, ['list.php','create.php','edit.php','cetak.php']) ? 'active open' : '' ?>">
            <a href="#" class="submenu-toggle">
                <i class="bi bi-file-earmark-text-fill"></i> <span>Data Surat</span>
                <i class="bi bi-chevron-down ms-auto arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="<?= $base_url ?>surat/list.php" class="<?= $current === 'list.php' ? 'active' : '' ?>"><i class="bi bi-list-ul"></i> Semua Surat</a></li>
                <li><a href="<?= $base_url ?>surat/create.php" class="<?= $current === 'create.php' ? 'active' : '' ?>"><i class="bi bi-plus-circle"></i> Tambah Surat</a></li>
                <li><a href="<?= $base_url ?>surat/cetak.php" class="<?= $current === 'cetak.php' ? 'active' : '' ?>"><i class="bi bi-printer"></i> Cetak Laporan</a></li>
            </ul>
        </li>

        <li>
            <a href="<?= $base_url ?>logout.php">
                <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
            </a>
        </li>
    </ul>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
