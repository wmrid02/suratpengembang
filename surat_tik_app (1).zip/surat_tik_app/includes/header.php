<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?>Admin Surat TIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= $base_url ?? '' ?>assets/css/style.css">
</head>
<body>
<div class="app-wrapper">

    <?php include __DIR__ . '/sidebar.php'; ?>

    <div class="main-content">
        <nav class="topbar">
            <button class="btn btn-sm btn-light d-lg-none" id="sidebarToggle"><i class="bi bi-list fs-4"></i></button>
            <h5 class="topbar-title mb-0"><?= htmlspecialchars($page_title ?? 'Dashboard') ?></h5>
            <div class="topbar-user dropdown">
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                    <div class="avatar-circle me-2"><?= strtoupper(substr($_SESSION['nama'] ?? 'A', 0, 1)) ?></div>
                    <span class="text-dark d-none d-sm-inline"><?= htmlspecialchars($_SESSION['nama'] ?? 'Admin') ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?= $base_url ?? '' ?>logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                </ul>
            </div>
        </nav>
        <main class="page-content">
