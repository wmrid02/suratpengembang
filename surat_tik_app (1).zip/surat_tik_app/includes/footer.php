        </main>
        <footer class="page-footer">
            &copy; <?= date('Y') ?> Admin Surat Pengembang TIK. All rights reserved.
        </footer>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $base_url ?? '' ?>assets/js/script.js"></script>
</body>
</html>
