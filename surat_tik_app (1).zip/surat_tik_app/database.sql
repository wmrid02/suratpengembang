-- =========================================================
-- Database: db_surat_tik
-- Aplikasi CRUD Admin Surat Pengembang TIK
-- =========================================================

CREATE DATABASE IF NOT EXISTS db_surat_tik CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_surat_tik;

-- =========================================================
-- Tabel admin (untuk login)
-- =========================================================
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Password default: admin123  (sudah di-hash dengan bcrypt)
INSERT INTO admin (username, password, nama_lengkap) VALUES
('admin', '$2b$10$AnwkYR3sCXcZEgWZY1dGsegikkq0ew4vM0qMK2fsgxZpOzn5x8e.2', 'Administrator TIK');

-- =========================================================
-- Tabel surat
-- =========================================================
CREATE TABLE IF NOT EXISTS surat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jenis_surat VARCHAR(150) NOT NULL,
    nomor_surat VARCHAR(150) NOT NULL,
    tanggal_ttd DATE DEFAULT NULL,
    pejabat_ttd VARCHAR(150) NOT NULL,
    pengantar_surat VARCHAR(150) NOT NULL,
    penerima_pengambil_surat VARCHAR(150) NOT NULL,
    keterangan TEXT,
    status_ttd ENUM('Sudah TTD','Belum TTD') NOT NULL DEFAULT 'Belum TTD',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- Contoh data (opsional, boleh dihapus)
-- =========================================================
INSERT INTO surat (jenis_surat, nomor_surat, tanggal_ttd, pejabat_ttd, pengantar_surat, penerima_pengambil_surat, keterangan, status_ttd) VALUES
('Surat Permohonan Pengembangan Aplikasi', '001/TIK/I/2026', '2026-01-10', 'Kepala Dinas Kominfo', 'Budi Santoso', 'Andi Wijaya', 'Permohonan pembuatan aplikasi absensi', 'Sudah TTD'),
('Surat Izin Akses Server', '002/TIK/I/2026', '2026-01-15', 'Kabid Infrastruktur', 'Siti Aminah', 'Rina Marlina', 'Izin akses server produksi', 'Sudah TTD'),
('Surat Pemberitahuan Maintenance', '003/TIK/II/2026', '2026-02-05', 'Kepala Dinas Kominfo', 'Ahmad Fauzi', 'Joko Prasetyo', 'Pemberitahuan maintenance rutin bulanan', 'Sudah TTD'),
('Surat Permohonan Domain', '004/TIK/II/2026', NULL, 'Kabid Aplikasi', 'Dewi Lestari', 'Fajar Nugraha', 'Menunggu tanda tangan pejabat', 'Belum TTD'),
('Surat Serah Terima Sistem', '005/TIK/III/2026', '2026-03-20', 'Kepala Dinas Kominfo', 'Rudi Hartono', 'Maya Sari', 'Serah terima sistem informasi kepegawaian', 'Sudah TTD');
