<?php
require_once '../includes/auth_check.php';
require_once '../config/database.php';

$base_url = '../';
$page_title = 'Data Surat';

// flash message
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$search        = trim($_GET['q'] ?? '');
$status        = $_GET['status'] ?? '';
$tanggal_awal  = trim($_GET['tanggal_awal'] ?? '');
$tanggal_akhir = trim($_GET['tanggal_akhir'] ?? '');

$sql = "SELECT * FROM surat WHERE 1=1";
$countSql = "SELECT COUNT(*) FROM surat WHERE 1=1";
$params = [];
$where = "";

if ($search !== '') {
    $where .= " AND (jenis_surat LIKE ? OR nomor_surat LIKE ? OR pejabat_ttd LIKE ? OR pengantar_surat LIKE ? OR penerima_pengambil_surat LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like, $like);
}
if ($status !== '' && in_array($status, ['Sudah TTD', 'Belum TTD'])) {
    $where .= " AND status_ttd = ?";
    $params[] = $status;
}
if ($tanggal_awal !== '') {
    $where .= " AND tanggal_ttd >= ?";
    $params[] = $tanggal_awal;
}
if ($tanggal_akhir !== '') {
    $where .= " AND tanggal_ttd <= ?";
    $params[] = $tanggal_akhir;
}

$sql      .= $where . " ORDER BY id DESC";
$countSql .= $where;

// hitung total data untuk pagination
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalData = (int) $countStmt->fetchColumn();

// pagination: maksimal 10 baris per halaman
$perPage    = 10;
$totalPages = max(1, (int) ceil($totalData / $perPage));
$page       = isset($_GET['page']) && ctype_digit($_GET['page']) ? (int) $_GET['page'] : 1;
$page       = max(1, min($page, $totalPages));
$offset     = ($page - 1) * $perPage;

$sql .= " LIMIT $perPage OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$suratList = $stmt->fetchAll();

// helper untuk membangun query string saat berpindah halaman (mempertahankan filter)
function buildPageUrl($p) {
    $q = $_GET;
    $q['page'] = $p;
    return '?' . http_build_query($q);
}

include '../includes/header.php';
?>

<?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
        <?= htmlspecialchars($flash['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span><i class="bi bi-file-earmark-text-fill me-1"></i> Daftar Surat Pengembang TIK</span>
        <div class="d-flex gap-2">
            <a href="cetak.php?<?= http_build_query(['q'=>$search,'status'=>$status,'tanggal_awal'=>$tanggal_awal,'tanggal_akhir'=>$tanggal_akhir]) ?>" target="_blank" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-file-earmark-pdf me-1"></i> Cetak Laporan PDF
            </a>
            <a href="create.php" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Surat
            </a>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-2 mb-3">
            <div class="col-md-4">
                <label class="form-label small text-muted mb-1">Pencarian</label>
                <input type="text" name="q" class="form-control" placeholder="Jenis, nomor, pejabat, pengantar, penerima..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted mb-1">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="Sudah TTD" <?= $status === 'Sudah TTD' ? 'selected' : '' ?>>Sudah TTD</option>
                    <option value="Belum TTD" <?= $status === 'Belum TTD' ? 'selected' : '' ?>>Belum TTD</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted mb-1">Tanggal Surat Dari</label>
                <input type="date" name="tanggal_awal" class="form-control" value="<?= htmlspecialchars($tanggal_awal) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small text-muted mb-1">Sampai</label>
                <input type="date" name="tanggal_akhir" class="form-control" value="<?= htmlspecialchars($tanggal_akhir) ?>">
            </div>
            <div class="col-md-1">
                <label class="form-label small text-muted mb-1 d-none d-md-block">&nbsp;</label>
                <button type="submit" class="btn btn-outline-primary w-100"><i class="bi bi-search"></i></button>
            </div>
            <div class="col-md-1">
                <label class="form-label small text-muted mb-1 d-none d-md-block">&nbsp;</label>
                <a href="list.php" class="btn btn-outline-secondary w-100"><i class="bi bi-arrow-counterclockwise"></i></a>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Jenis Surat</th>
                        <th>Nomor Surat</th>
                        <th>Tanggal TTD</th>
                        <th>Pejabat yang TTD</th>
                        <th>Pengantar Surat</th>
                        <th>Penerima / Pengambil Surat</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($suratList)): ?>
                    <tr><td colspan="10" class="text-center text-muted py-4">Data surat tidak ditemukan.</td></tr>
                <?php else: $no = $offset + 1; foreach ($suratList as $s): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($s['jenis_surat']) ?></td>
                        <td><?= htmlspecialchars($s['nomor_surat']) ?></td>
                        <td><?= $s['tanggal_ttd'] ? date('d-m-Y', strtotime($s['tanggal_ttd'])) : '-' ?></td>
                        <td><?= htmlspecialchars($s['pejabat_ttd']) ?></td>
                        <td><?= htmlspecialchars($s['pengantar_surat']) ?></td>
                        <td><?= htmlspecialchars($s['penerima_pengambil_surat']) ?></td>
                        <td><?= htmlspecialchars($s['keterangan'] ?: '-') ?></td>
                        <td>
                            <?php if ($s['status_ttd'] === 'Sudah TTD'): ?>
                                <span class="badge badge-success">Sudah TTD</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Belum TTD</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center text-nowrap">
                            <a href="edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <button type="button" class="btn btn-sm btn-outline-danger btn-delete"
                                    data-id="<?= $s['id'] ?>"
                                    data-nomor="<?= htmlspecialchars($s['nomor_surat']) ?>"
                                    title="Hapus">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="d-flex flex-column align-items-center mt-3">
            <nav aria-label="Navigasi halaman">
                <ul class="pagination pagination-sm mb-1">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= buildPageUrl(max(1, $page - 1)) ?>">&laquo;</a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="<?= buildPageUrl($i) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= buildPageUrl(min($totalPages, $page + 1)) ?>">&raquo;</a>
                    </li>
                </ul>
            </nav>
            <small class="text-muted">Halaman <?= $page ?> dari <?= $totalPages ?> &middot; Total <?= $totalData ?> data</small>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Form hapus tersembunyi -->
<form id="deleteForm" action="delete.php" method="POST" class="d-none">
    <input type="hidden" name="id" id="deleteId">
</form>

<!-- Modal Konfirmasi Hapus -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Konfirmasi Hapus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                Yakin ingin menghapus surat nomor <strong id="deleteNomor"></strong>? Tindakan ini tidak dapat dibatalkan.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Ya, Hapus</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const deleteModalEl = document.getElementById('deleteModal');
    const deleteModal = new bootstrap.Modal(deleteModalEl);
    let selectedId = null;

    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function () {
            selectedId = this.dataset.id;
            document.getElementById('deleteNomor').textContent = this.dataset.nomor;
            deleteModal.show();
        });
    });

    document.getElementById('confirmDeleteBtn').addEventListener('click', function () {
        document.getElementById('deleteId').value = selectedId;
        document.getElementById('deleteForm').submit();
    });
});
</script>

<?php include '../includes/footer.php'; ?>
