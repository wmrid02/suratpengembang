<?php
require_once '../includes/auth_check.php';
require_once '../config/database.php';

$search        = trim($_GET['q'] ?? '');
$status        = $_GET['status'] ?? '';
$tanggal_awal  = trim($_GET['tanggal_awal'] ?? '');
$tanggal_akhir = trim($_GET['tanggal_akhir'] ?? '');

$sql = "SELECT * FROM surat WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (jenis_surat LIKE ? OR nomor_surat LIKE ? OR pejabat_ttd LIKE ? OR pengantar_surat LIKE ? OR penerima_pengambil_surat LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like, $like, $like);
}
if ($status !== '' && in_array($status, ['Sudah TTD', 'Belum TTD'])) {
    $sql .= " AND status_ttd = ?";
    $params[] = $status;
}
if ($tanggal_awal !== '') {
    $sql .= " AND tanggal_ttd >= ?";
    $params[] = $tanggal_awal;
}
if ($tanggal_akhir !== '') {
    $sql .= " AND tanggal_ttd <= ?";
    $params[] = $tanggal_akhir;
}

$sql .= " ORDER BY tanggal_ttd IS NULL, tanggal_ttd ASC, id ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$suratList = $stmt->fetchAll();

$totalData  = count($suratList);
$totalTtd   = count(array_filter($suratList, fn($s) => $s['status_ttd'] === 'Sudah TTD'));
$totalBelum = $totalData - $totalTtd;

// deskripsi periode untuk kop laporan
$periodeText = 'Semua Periode';
if ($tanggal_awal !== '' || $tanggal_akhir !== '') {
    $awalFmt  = $tanggal_awal !== ''  ? date('d-m-Y', strtotime($tanggal_awal))  : '...';
    $akhirFmt = $tanggal_akhir !== '' ? date('d-m-Y', strtotime($tanggal_akhir)) : '...';
    $periodeText = "$awalFmt s/d $akhirFmt";
}

$dicetakOleh = $_SESSION['nama'] ?? 'Administrator';
$tanggalCetak = date('d-m-Y H:i');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Surat Pengembang TIK</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 15mm 12mm;
        }
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, Helvetica, sans-serif;
            color: #1a1a1a;
            margin: 0;
            padding: 0;
            font-size: 12px;
        }
        .report-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
            border-bottom: 3px solid #1e2337;
            padding-bottom: 12px;
            margin-bottom: 4px;
            text-align: center;
        }
        .report-header .logo-box {
            width: 56px; height: 56px;
            border-radius: 50%;
            background: #4f6ef7;
            color: #fff;
            display: flex; align-items: center; justify-content: center;
            font-size: 26px;
            flex-shrink: 0;
        }
        .report-header h1 {
            font-size: 18px;
            margin: 0;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            color: #1e2337;
        }
        .report-header h2 {
            font-size: 14px;
            margin: 2px 0 0;
            font-weight: 500;
            color: #4a4f66;
        }
        .report-meta {
            display: flex;
            justify-content: space-between;
            font-size: 11.5px;
            margin: 10px 0 14px;
            color: #333;
        }
        .report-meta div span { font-weight: 600; }

        table.report-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }
        table.report-table th, table.report-table td {
            border: 1px solid #444;
            padding: 6px 7px;
            vertical-align: top;
        }
        table.report-table thead th {
            background: #1e2337;
            color: #fff;
            text-align: center;
            font-weight: 600;
            font-size: 10.5px;
        }
        table.report-table tbody tr:nth-child(even) { background: #f4f6fb; }
        table.report-table td.center { text-align: center; }
        table.report-table td.no-col { text-align: center; width: 28px; }

        .status-pill {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }
        .status-sudah { background: #dcfce7; color: #166534; }
        .status-belum { background: #fef3c7; color: #92400e; }

        .summary-box {
            display: flex;
            gap: 14px;
            margin-top: 14px;
            font-size: 11.5px;
        }
        .summary-box .box {
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 8px 14px;
            flex: 1;
            text-align: center;
        }
        .summary-box .box .val { font-size: 16px; font-weight: 700; color: #1e2337; }
        .summary-box .box .lbl { font-size: 10.5px; color: #6b6f80; }

        .sign-section {
            margin-top: 40px;
            display: flex;
            justify-content: flex-end;
            font-size: 12px;
        }
        .sign-section .sign-box {
            text-align: center;
            width: 220px;
        }
        .sign-space { height: 60px; }

        .no-print-toolbar {
            position: fixed;
            top: 12px; right: 12px;
            z-index: 999;
        }
        .no-print-toolbar button {
            background: #4f6ef7;
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .no-print-toolbar button:hover { background: #3a56d4; }

        @media print {
            .no-print-toolbar { display: none !important; }
            body { font-size: 11px; }
        }
    </style>
</head>
<body>

    <div class="no-print-toolbar">
        <button onclick="window.print()">🖨️ Cetak / Simpan sebagai PDF</button>
    </div>

    <div class="report-header">
        <div class="logo-box">✉</div>
        <div>
            <h1>Laporan Data Surat Pengembang TIK</h1>
            <h2>Rekapitulasi Administrasi Surat</h2>
        </div>
    </div>

    <div class="report-meta">
        <div>
            <div>Periode Tanggal TTD&nbsp;: <span><?= htmlspecialchars($periodeText) ?></span></div>
            <div>Status Surat&nbsp;: <span><?= $status !== '' ? htmlspecialchars($status) : 'Semua Status' ?></span></div>
            <?php if ($search !== ''): ?>
            <div>Kata Kunci&nbsp;: <span><?= htmlspecialchars($search) ?></span></div>
            <?php endif; ?>
        </div>
        <div style="text-align:right">
            <div>Dicetak oleh&nbsp;: <span><?= htmlspecialchars($dicetakOleh) ?></span></div>
            <div>Tanggal Cetak&nbsp;: <span><?= $tanggalCetak ?></span></div>
        </div>
    </div>

    <table class="report-table">
        <thead>
            <tr>
                <th style="width:28px">No</th>
                <th>Jenis Surat</th>
                <th>Nomor Surat</th>
                <th style="width:75px">Tanggal TTD</th>
                <th>Pejabat yang TTD</th>
                <th>Pengantar Surat</th>
                <th>Penerima / Pengambil Surat</th>
                <th>Keterangan</th>
                <th style="width:70px">Status</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($suratList)): ?>
            <tr><td colspan="9" class="center">Tidak ada data sesuai filter yang dipilih.</td></tr>
        <?php else: $no = 1; foreach ($suratList as $s): ?>
            <tr>
                <td class="no-col"><?= $no++ ?></td>
                <td><?= htmlspecialchars($s['jenis_surat']) ?></td>
                <td><?= htmlspecialchars($s['nomor_surat']) ?></td>
                <td class="center"><?= $s['tanggal_ttd'] ? date('d-m-Y', strtotime($s['tanggal_ttd'])) : '-' ?></td>
                <td><?= htmlspecialchars($s['pejabat_ttd']) ?></td>
                <td><?= htmlspecialchars($s['pengantar_surat']) ?></td>
                <td><?= htmlspecialchars($s['penerima_pengambil_surat']) ?></td>
                <td><?= htmlspecialchars($s['keterangan'] ?: '-') ?></td>
                <td class="center">
                    <?php if ($s['status_ttd'] === 'Sudah TTD'): ?>
                        <span class="status-pill status-sudah">Sudah TTD</span>
                    <?php else: ?>
                        <span class="status-pill status-belum">Belum TTD</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>

    <div class="summary-box">
        <div class="box">
            <div class="val"><?= $totalData ?></div>
            <div class="lbl">Total Surat</div>
        </div>
        <div class="box">
            <div class="val"><?= $totalTtd ?></div>
            <div class="lbl">Sudah TTD</div>
        </div>
        <div class="box">
            <div class="val"><?= $totalBelum ?></div>
            <div class="lbl">Belum TTD</div>
        </div>
    </div>

    <div class="sign-section">
        <div class="sign-box">
            <div>Mengetahui,</div>
            <div class="sign-space"></div>
            <div style="border-top:1px solid #333; padding-top:4px;">( ................................... )</div>
        </div>
    </div>

    <script>
        // Opsional: langsung buka dialog cetak saat halaman dimuat
        // window.onload = () => window.print();
    </script>
</body>
</html>
