<?php
require_once '../includes/auth_check.php';
require_once '../config/database.php';

$base_url = '../';
$page_title = 'Edit Surat';

$id = $_GET['id'] ?? $_POST['id'] ?? null;
if (!$id || !ctype_digit((string)$id)) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'ID surat tidak valid.'];
    header('Location: list.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM surat WHERE id = ?");
$stmt->execute([$id]);
$data = $stmt->fetch();

if (!$data) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Data surat tidak ditemukan.'];
    header('Location: list.php');
    exit;
}

$errors = [];
$form = $data;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['jenis_surat']     = trim($_POST['jenis_surat'] ?? '');
    $form['nomor_surat']     = trim($_POST['nomor_surat'] ?? '');
    $form['tanggal_ttd']     = trim($_POST['tanggal_ttd'] ?? '');
    $form['pejabat_ttd']     = trim($_POST['pejabat_ttd'] ?? '');
    $form['pengantar_surat'] = trim($_POST['pengantar_surat'] ?? '');
    $form['penerima_pengambil_surat'] = trim($_POST['penerima_pengambil_surat'] ?? '');
    $form['keterangan']      = trim($_POST['keterangan'] ?? '');
    $form['status_ttd']      = ($_POST['status_ttd'] ?? '') === 'Sudah TTD' ? 'Sudah TTD' : 'Belum TTD';

    if ($form['jenis_surat'] === '')     $errors[] = 'Jenis Surat wajib diisi.';
    if ($form['nomor_surat'] === '')     $errors[] = 'Nomor Surat wajib diisi.';
    if ($form['pejabat_ttd'] === '')     $errors[] = 'Pejabat yang TTD wajib diisi.';
    if ($form['pengantar_surat'] === '') $errors[] = 'Pengantar Surat wajib diisi.';
    if ($form['penerima_pengambil_surat'] === '') $errors[] = 'Penerima / Pengambil Surat wajib diisi.';
    if ($form['status_ttd'] === 'Sudah TTD' && $form['tanggal_ttd'] === '') {
        $errors[] = 'Tanggal TTD wajib diisi jika status Sudah TTD.';
    }

    // cek duplikasi nomor surat (kecuali punya sendiri)
    if (empty($errors)) {
        $cek = $pdo->prepare("SELECT id FROM surat WHERE nomor_surat = ? AND id != ?");
        $cek->execute([$form['nomor_surat'], $id]);
        if ($cek->fetch()) {
            $errors[] = 'Nomor Surat sudah terdaftar, gunakan nomor lain.';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            UPDATE surat SET
                jenis_surat = ?, nomor_surat = ?, tanggal_ttd = ?, pejabat_ttd = ?,
                pengantar_surat = ?, penerima_pengambil_surat = ?, keterangan = ?, status_ttd = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $form['jenis_surat'],
            $form['nomor_surat'],
            $form['tanggal_ttd'] !== '' ? $form['tanggal_ttd'] : null,
            $form['pejabat_ttd'],
            $form['pengantar_surat'],
            $form['penerima_pengambil_surat'],
            $form['keterangan'],
            $form['status_ttd'],
            $id,
        ]);

        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Data surat berhasil diperbarui.'];
        header('Location: list.php');
        exit;
    }
}

include '../includes/header.php';
?>

<div class="card shadow-sm">
    <div class="card-header">
        <i class="bi bi-pencil-square me-1"></i> Edit Data Surat
    </div>
    <div class="card-body">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="id" value="<?= $id ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Jenis Surat <span class="text-danger">*</span></label>
                    <input type="text" name="jenis_surat" class="form-control" value="<?= htmlspecialchars($form['jenis_surat']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nomor Surat <span class="text-danger">*</span></label>
                    <input type="text" name="nomor_surat" class="form-control" value="<?= htmlspecialchars($form['nomor_surat']) ?>" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Status TTD</label>
                    <select name="status_ttd" class="form-select">
                        <option value="Belum TTD" <?= $form['status_ttd'] === 'Belum TTD' ? 'selected' : '' ?>>Belum TTD</option>
                        <option value="Sudah TTD" <?= $form['status_ttd'] === 'Sudah TTD' ? 'selected' : '' ?>>Sudah TTD</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tanggal TTD</label>
                    <input type="date" name="tanggal_ttd" class="form-control" value="<?= htmlspecialchars($form['tanggal_ttd'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Pejabat yang TTD <span class="text-danger">*</span></label>
                    <input type="text" name="pejabat_ttd" class="form-control" value="<?= htmlspecialchars($form['pejabat_ttd']) ?>" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Pengantar Surat <span class="text-danger">*</span></label>
                    <input type="text" name="pengantar_surat" class="form-control" value="<?= htmlspecialchars($form['pengantar_surat']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Penerima / Pengambil Surat <span class="text-danger">*</span></label>
                    <input type="text" name="penerima_pengambil_surat" class="form-control" value="<?= htmlspecialchars($form['penerima_pengambil_surat']) ?>" required>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="keterangan" class="form-control" value="<?= htmlspecialchars($form['keterangan']) ?>">
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save2 me-1"></i> Update</button>
                <a href="list.php" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
