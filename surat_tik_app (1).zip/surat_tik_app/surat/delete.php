<?php
require_once '../includes/auth_check.php';
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;

    if ($id && ctype_digit((string)$id)) {
        $stmt = $pdo->prepare("DELETE FROM surat WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Data surat berhasil dihapus.'];
    } else {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'ID surat tidak valid.'];
    }
}

header('Location: list.php');
exit;
