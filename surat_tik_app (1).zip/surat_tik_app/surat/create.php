<?php
require_once '../includes/auth_check.php';
require_once '../config/database.php';

$base_url = '../';
$page_title = 'Tambah Surat';

$errors = [];
$form = [
    'jenis_surat'     => '',
    'nomor_surat'     => '',
    'tanggal_ttd'     => '',
    'pejabat_ttd'     => '',
    'pengantar_surat' => '',
    'penerima_pengambil_surat' => '',
    'keterangan'      => '',
    'status_ttd'      => 'Belum TTD',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['jenis_surat']     = trim($_POST['jenis_surat'] ?? '');
    $form['nomor_surat']     = trim($_POST['nomor_surat'] ?? '');
    $form['tanggal_ttd']     = trim($_POST['tanggal_ttd'] ?? '');
    $form['pejabat_ttd']     = trim($_POST['pejabat_ttd'] ?? '');
    $form['pengantar_surat'] = trim($_POST['pengantar_surat'] ?? '');
    $form['penerima_pengambil_surat'] = trim($_POST['penerima_pengambil_surat'] ?? '');
    $form['keterangan']      = trim($_POST['keterangan'] ?? '');
    $form['status_ttd']      = ($_POST['status_ttd'] ?? '') === 'Sudah TTD' ? 'Sudah TTD' : 'Belum TTD';

    if ($form['jenis_surat'] === '')     $errors[] = 'Jenis Surat wajib diisi.';
    if ($form['nomor_surat'] === '')     $errors[] = 'Nomor Surat wajib diisi.';
    if ($form['pejabat_ttd'] === '')     $errors[] = 'Pejabat yang TTD wajib diisi.';
    if ($form['pengantar_surat'] === '') $errors[] = 'Pengantar Surat wajib diisi.';
    if ($form['penerima_pengambil_surat'] === '') $errors[] = 'Penerima / Pengambil Surat wajib diisi.';
    if ($form['status_ttd'] === 'Sudah TTD' && $form['tanggal_ttd'] === '') {
        $errors[] = 'Tanggal TTD wajib diisi jika status Sudah TTD.';
    }

    // cek duplikasi nomor surat
    if (empty($errors)) {
        $cek = $pdo->prepare("SELECT id FROM surat WHERE nomor_surat = ?");
        $cek->execute([$form['nomor_surat']]);
        if ($cek->fetch()) {
            $errors[] = 'Nomor Surat sudah terdaftar, gunakan nomor lain.';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO surat (jenis_surat, nomor_surat, tanggal_ttd, pejabat_ttd, pengantar_surat, penerima_pengambil_surat, keterangan, status_ttd)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $form['jenis_surat'],
            $form['nomor_surat'],
            $form['tanggal_ttd'] !== '' ? $form['tanggal_ttd'] : null,
            $form['pejabat_ttd'],
            $form['pengantar_surat'],
            $form['penerima_pengambil_surat'],
            $form['keterangan'],
            $form['status_ttd'],
        ]);

        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Data surat berhasil ditambahkan.'];
        header('Location: list.php');
        exit;
    }
}

include '../includes/header.php';
?>

<div class="card shadow-sm">
    <div class="card-header">
        <i class="bi bi-plus-circle me-1"></i> Tambah Data Surat
    </div>
    <div class="card-body">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Jenis Surat <span class="text-danger">*</span></label>
                    <input type="text" name="jenis_surat" class="form-control" value="<?= htmlspecialchars($form['jenis_surat']) ?>" placeholder="Contoh: Surat Permohonan Pengembangan Aplikasi" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nomor Surat <span class="text-danger">*</span></label>
                    <input type="text" name="nomor_surat" class="form-control" value="<?= htmlspecialchars($form['nomor_surat']) ?>" placeholder="Contoh: 001/TIK/I/2026" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Status TTD</label>
                    <select name="status_ttd" class="form-select" id="statusSelect">
                        <option value="Belum TTD" <?= $form['status_ttd'] === 'Belum TTD' ? 'selected' : '' ?>>Belum TTD</option>
                        <option value="Sudah TTD" <?= $form['status_ttd'] === 'Sudah TTD' ? 'selected' : '' ?>>Sudah TTD</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tanggal TTD</label>
                    <input type="date" name="tanggal_ttd" class="form-control" value="<?= htmlspecialchars($form['tanggal_ttd']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Pejabat yang TTD <span class="text-danger">*</span></label>
                    <input type="text" name="pejabat_ttd" class="form-control" value="<?= htmlspecialchars($form['pejabat_ttd']) ?>" placeholder="Nama pejabat" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Pengantar Surat <span class="text-danger">*</span></label>
                    <input type="text" name="pengantar_surat" class="form-control" value="<?= htmlspecialchars($form['pengantar_surat']) ?>" placeholder="Nama pengantar surat" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Penerima / Pengambil Surat <span class="text-danger">*</span></label>
                    <input type="text" name="penerima_pengambil_surat" class="form-control" value="<?= htmlspecialchars($form['penerima_pengambil_surat']) ?>" placeholder="Nama penerima / pengambil surat" required>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="keterangan" class="form-control" value="<?= htmlspecialchars($form['keterangan']) ?>" placeholder="Keterangan tambahan (opsional)">
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save2 me-1"></i> Simpan</button>
                <a href="list.php" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
