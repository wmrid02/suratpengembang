-- =========================================================
-- MIGRASI: Jalankan file ini HANYA jika Anda sudah pernah
-- meng-install database sebelumnya (database.sql versi lama)
-- dan ingin menambahkan kolom baru tanpa install ulang dari nol.
--
-- Jika instalasi baru, cukup import database.sql saja
-- (kolom ini sudah termasuk di dalamnya).
-- =========================================================

USE db_surat_tik;

ALTER TABLE surat
    ADD COLUMN penerima_pengambil_surat VARCHAR(150) NOT NULL DEFAULT ''
    AFTER pengantar_surat;
