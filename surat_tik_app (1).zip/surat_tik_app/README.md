# Aplikasi CRUD Admin Surat Pengembang TIK

Aplikasi web berbasis **PHP native + MySQL + Bootstrap 5 + Chart.js** untuk mengelola data surat
pengembang TIK, lengkap dengan login admin, dashboard grafik rekap bulanan, sidebar menu, dan CRUD data surat.

## Fitur

1. **Login Admin** — autentikasi dengan session & password ter-hash (bcrypt).
2. **Dashboard** — kartu statistik (Total Surat, Sudah TTD, Belum TTD) + diagram batang rekap surat
   yang sudah TTD per bulan (bisa difilter per tahun) menggunakan Chart.js.
3. **Sidebar Menu** — judul navbar "SURAT PENGEMBANG TIK", menu di sebelah kiri dengan submenu
   "Data Surat" yang bisa dibuka/tutup (accordion), responsif untuk tampilan mobile.
4. **CRUD Data Surat** — Create, Read, Update, Delete untuk data surat dengan kolom:
   - No
   - Jenis Surat
   - Nomor Surat
   - Tanggal TTD
   - Pejabat yang TTD
   - Pengantar Surat
   - **Penerima / Pengambil Surat**
   - Keterangan
   - (tambahan) Status TTD — otomatis dipakai untuk rekap grafik dashboard

   Dilengkapi fitur pencarian, filter status, **filter rentang tanggal surat (Tanggal TTD dari — sampai)**,
   konfirmasi hapus (modal), dan **pagination maksimal 10 baris per halaman** dengan navigasi nomor halaman
   kecil di bawah tabel.
5. **Cetak Laporan ke PDF** — halaman laporan (`surat/cetak.php`) dengan tampilan tabel presisi & rapi
   (kop laporan, ringkasan jumlah surat, kolom tanda tangan), mengikuti filter yang sedang aktif
   (pencarian, status, rentang tanggal). Gunakan tombol **"Cetak / Simpan sebagai PDF"** di halaman
   tersebut — browser akan membuka dialog cetak, pilih **"Save as PDF" / "Simpan sebagai PDF"** sebagai
   tujuan cetak untuk menghasilkan file PDF. Layout sudah diatur ke ukuran kertas A4 landscape agar
   semua kolom tampil presisi tanpa terpotong.

## Struktur Folder

```
surat_tik_app/
├── assets/
│   ├── css/style.css
│   └── js/script.js
├── config/
│   └── database.php        # konfigurasi koneksi DB
├── includes/
│   ├── auth_check.php      # proteksi halaman (wajib login)
│   ├── header.php
│   ├── sidebar.php
│   └── footer.php
├── surat/
│   ├── list.php             # daftar / read data surat + filter + pagination
│   ├── create.php           # tambah data surat
│   ├── edit.php              # edit data surat
│   ├── delete.php            # hapus data surat
│   └── cetak.php             # cetak laporan PDF (print-friendly)
├── database.sql              # skema database + data contoh
├── migration_add_penerima.sql # migrasi kolom baru untuk instalasi lama
├── index.php                  # dashboard
├── login.php
├── logout.php
└── README.md
```

## Cara Instalasi (XAMPP / Laragon)

1. **Copy folder** `surat_tik_app` ke dalam folder `htdocs` (XAMPP) atau `www` (Laragon).
2. **Buat database**: buka phpMyAdmin, lalu import file `database.sql`
   (ini akan otomatis membuat database `db_surat_tik`, tabel `admin`, tabel `surat`, beserta data contoh).

   > **Sudah pernah install versi sebelumnya?** Cukup import `migration_add_penerima.sql` untuk
   > menambahkan kolom "Penerima / Pengambil Surat" tanpa perlu install ulang dari nol.
3. **Sesuaikan koneksi database** jika perlu, buka `config/database.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'db_surat_tik');
   ```
4. **Jalankan Apache & MySQL** dari XAMPP/Laragon Control Panel.
5. Buka browser ke `http://localhost/surat_tik_app/login.php`.

## Login Default

| Username | Password  |
|----------|-----------|
| admin    | admin123  |

> Disarankan untuk mengganti password default setelah login pertama (bisa update langsung
> lewat tabel `admin` di database menggunakan hash bcrypt baru, atau tambahkan fitur ganti password sesuai kebutuhan).

## Catatan Teknis

- Menggunakan **PDO** dengan prepared statements untuk mencegah SQL Injection.
- Password admin disimpan dalam bentuk **bcrypt hash** (`password_hash` / `password_verify`).
- Semua input di-escape dengan `htmlspecialchars()` untuk mencegah XSS.
- Session digunakan untuk menjaga status login (`includes/auth_check.php` otomatis redirect ke
  halaman login jika belum login).
- Status TTD (`Sudah TTD` / `Belum TTD`) digunakan sebagai dasar perhitungan diagram rekap bulanan
  di dashboard, berdasarkan kolom `tanggal_ttd`.
- Grafik dashboard menggunakan **Chart.js** (dimuat via CDN) dan bisa difilter per tahun.

## Kebutuhan Server

- PHP 7.4+ (disarankan PHP 8.x)
- MySQL 5.7+ / MariaDB 10.3+
- Ekstensi PHP: `pdo_mysql`

Selamat menggunakan aplikasi! Jika ingin menambahkan fitur seperti export PDF/Excel, upload
lampiran surat, atau manajemen banyak admin, struktur ini sudah siap dikembangkan lebih lanjut.
